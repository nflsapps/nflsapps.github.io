<!DOCTYPE html>
<html>
<head>
<title>Login - AppHub</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    
<link rel="stylesheet" href="http://cdn2.editmysite.com/css/sites.css?buildTime=1234" type="text/css" /><link rel='stylesheet' type='text/css' href='http://cdn1.editmysite.com/editor/libraries/fancybox/fancybox.css?1234' />
<link rel='stylesheet' type='text/css' href='files/main_style.css?1409984621' title='wsite-theme-css' />
<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,700,400italic,700italic&subset=latin,latin-ext' rel='stylesheet' type='text/css' />
<link href='http://fonts.googleapis.com/css?family=Arvo:400,700,400italic,700italic&subset=latin,latin-ext' rel='stylesheet' type='text/css' />
<style type='text/css'>
.wsite-elements.wsite-not-footer div.paragraph, .wsite-elements.wsite-not-footer p, .wsite-elements.wsite-not-footer .product-block .product-title, .wsite-elements.wsite-not-footer .product-description, .wsite-elements.wsite-not-footer .wsite-form-field label, .wsite-elements.wsite-not-footer .wsite-form-field label, #wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {}
#wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {}
.wsite-elements.wsite-footer div.paragraph, .wsite-elements.wsite-footer p, .wsite-elements.wsite-footer .product-block .product-title, .wsite-elements.wsite-footer .product-description, .wsite-elements.wsite-footer .wsite-form-field label, .wsite-elements.wsite-footer .wsite-form-field label{}
.wsite-elements.wsite-not-footer h2, .wsite-elements.wsite-not-footer .product-long .product-title, .wsite-elements.wsite-not-footer .product-large .product-title, .wsite-elements.wsite-not-footer .product-small .product-title, #wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {}
#wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {}
.wsite-elements.wsite-footer h2, .wsite-elements.wsite-footer .product-long .product-title, .wsite-elements.wsite-footer .product-large .product-title, .wsite-elements.wsite-footer .product-small .product-title{}
#wsite-title {}
.wsite-menu-default a {}
.wsite-menu a {}
.wsite-image div, .wsite-caption {}
.galleryCaptionInnerText {}
.fancybox-title {}
.wslide-caption-text {}
.wsite-phone {}
.wsite-headline {}
.wsite-headline-paragraph {}
.wsite-button-inner {}
.wsite-not-footer blockquote, #wsite-com-product-tab blockquote {}
.wsite-footer blockquote {}
.blog-header h2 a {}
#wsite-content h2.wsite-product-title {}
.wsite-product .wsite-product-price a {}
</style>

<script><!--
var STATIC_BASE = '//cdn1.editmysite.com/';
var STYLE_PREFIX = 'wsite';
//-->
</script>
<script src='jquery.min.js'></script>
<script src='http://cdn2.editmysite.com/js/site/main.js?buildTime=1234'></script>
<script>_W.relinquish && _W.relinquish()</script>
<script type='text/javascript'><!--
var IS_ARCHIVE=1;
(function(jQuery){
function initFlyouts(){initPublishedFlyoutMenus([{"id":"511272788535010122","title":"HOME","url":"index.html","target":""},{"id":"962502244547413226","title":"NEWS","url":"news.html","target":""},{"id":"678304809576138030","title":"ABOUT","url":"about.html","target":""},{"id":"366252425714719181","title":"MEMBERS","url":"http:\/\/nflsapps.sinaapp.com\/members","target":""}],"656304961575486340","<li><a href='#'>{{title}}<\/a><\/li>",'',false)}
if (jQuery) {
if (jQuery.browser.msie && !window.flyoutMenusRefreshable) window.onload = initFlyouts;
else jQuery(initFlyouts);
}else{
if (Prototype.Browser.IE) window.onload = initFlyouts;
else document.observe('dom:loaded', initFlyouts);
}
})(window._W && _W.jQuery)
//-->
</script>

<script type="text/javascript">
function setCookie(c_name,value,expiredays)
{
var exdate=new Date()
exdate.setDate(exdate.getDate()+expiredays)
document.cookie=c_name+ "=" +escape(value)+
((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
}
function getCookie(c_name)
{
if (document.cookie.length>0)
  {
  c_start=document.cookie.indexOf(c_name + "=")
  if (c_start!=-1)
    { 
    c_start=c_start + c_name.length+1 
    c_end=document.cookie.indexOf(";",c_start)
    if (c_end==-1) c_end=document.cookie.length
    return unescape(document.cookie.substring(c_start,c_end))
    } 
  }
return ""
}
</script>
</head>
<body class='splash-page wsite-background  wsite-theme-light wsite-page-login'>
<div id="nav-wrap">
        <div class="container">
			<table id="header">
                <tr>
                    <td id="logo"><span class='wsite-logo'><a href=''><span id="wsite-title">AppHub</span></a></span></td>
					<td id="nav"> <ul class='wsite-menu-default'><li id='pg511272788535010122'><a href='index.html'>HOME</a></li><li id='pg962502244547413226'><a href='news.html'>NEWS</a></li><li id='pg678304809576138030'><a href='about.html'>ABOUT</a></li><li id='pg366252425714719181'><a href='http://nflsapps.sinaapp.com/members'>MEMBERS</a></li></ul> </td>
					<!--<td class="search">{search}</td>-->
				</tr>
			</table>
        </div><!-- end container -->
    </div><!-- end nav-wrap --> 

	<div id="splash-wrap">
		<div class="main-wrap">
				<div id="content-section">
					<div id='wsite-content' class='wsite-elements wsite-not-footer'>
<div><div class="wsite-multicol"><div class='wsite-multicol-table-wrap' style='margin:0 -15px'>
<table class='wsite-multicol-table'>
<tbody class='wsite-multicol-tbody'>
<tr class='wsite-multicol-tr'>
<td class='wsite-multicol-col ' style='width:50%;padding:0 15px'>

<h2 class="wsite-content-title" style="text-align:left;">Login to apphub</h2>

</td>
<td class='wsite-multicol-col ' style='width:50%;padding:0 15px'>

<div style="text-align:right;"><div style="height: 10px; overflow: hidden;"></div>
<a class="wsite-button wsite-button-large wsite-button-normal" href="eula.html" >
<span class="wsite-button-inner">立即加入</span>
</a>
<div style="height: 10px; overflow: hidden;"></div></div>

</td>
</tr>
</tbody>
</table>
</div></div></div>

<div><div style="height: 20px; overflow: hidden; width: 100%;"></div>
<hr class="styled-hr" style="width:100%;"></hr>
<div style="height: 20px; overflow: hidden; width: 100%;"></div></div>

<div>
	<p style = "color:#ff6666">
		<?php
			echo $_REQUEST["error"];
		?>
	</p>
<form enctype="multipart/form-data" action="index.php" method="POST" id="form">
<div id="122396486691854602-form-parent" class="wsite-form-container" style="margin-top:10px;">
  <ul class="formlist" id="122396486691854602-form-list">
    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
				<label class="wsite-form-label" for="input-895191635820858015">用户名 <span class="form-required"></span></label>
				<div class="wsite-form-input-container">
					<input id="input-895191635820858015" class="wsite-form-input wsite-input wsite-input-width-200px" type="text" name="user" style = "color:white"/>
				</div>
				<div id="instructions-895191635820858015" class="wsite-form-instructions" style="display:none;"></div>
			</div></div>

<div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
				<label class="wsite-form-label" for="input-784673213210308608">密码 <span class="form-required"></span></label>
				<div class="wsite-form-input-container">
					<input id="input-784673213210308608" class="wsite-form-input wsite-input wsite-input-width-200px" type="password" name="pswd" style = "color:white"/>
				</div>
				<div id="instructions-784673213210308608" class="wsite-form-instructions" style="display:none;"></div>
			</div></div>
			<br />
  </ul>
</div>
<div style="display:none; visibility:hidden;">
  <input type="text" name="wsite_subject" />
</div>
<div style="text-align:left; margin-top:10px; margin-bottom:10px;">
  <input type="hidden" name="form_version" value="2" />
  <input type="hidden" name="wsite_approved" id="wsite-approved" value="approved" />
  <input type="hidden" name="ucfid" value="122396486691854602" />
  <input type='submit' style='position:absolute;top:0;left:-9999px;width:1px;height:1px' /><a class='wsite-button' onclick = "document.getElementById('form').submit()"><span class='wsite-button-inner'>登录</span></a>
</div>
</form>


</div>

<div class="paragraph" style="text-align:left;"><font size="3">&#24536;&#35760;&#23494;&#30721;&#65311;&#35831;&#21457;&#37038;&#20214;&#33267;<a href="mailto:nflsapps@gmail.com">nflsapps@gmail.com</a>&#65292;&#26631;&#39064;&#20026;&#24674;&#22797;&#23494;&#30721;&#65292;&#25105;&#20204;&#23558;&#24110;&#24744;&#37325;&#32622;</font></div></div>

				</div>
			</div>
	</div><!-- end splash-wrap --> 


<script type="text/javascript" src="files/theme/custom.js"></script>

</body>
</html>