<?php
$key0 = "QLOEDep04n5BxAMjHZ5fxlMpBF48t0vB";
$key1 = "ivMubPzs0PoBR73aZOwDLgJREkdFgT1c";
$key2 = "U7vxGDPdVkcvSk3FPj2SFQ4pT4211hqe";
$key3 = "jYuLPGtXgZwTkJ4beFf2Lh5dtyRi9Wak";
$key4 = "fRa78ag7tcIHtfMemhRUuquWu7IaVEl5";
$key5 = "dQHFp3Qhy6NmJnhfWeEqF25oJOhKhR1K";
$key6 = "1prjeCHihSTtE25qQ3vVTe1hInlpZlw0";
$key7 = "olHZ2U4J3S2QW8amxVHnYsUTweXlIWzW";
?>
